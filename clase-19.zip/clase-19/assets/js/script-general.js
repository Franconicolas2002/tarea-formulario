console.log('funciona');

let nombre = $('#nombre').val();
let apellido = $('#apellido').val();
let profesion = $('#profesion').val();
let numero = $('#numero').val();
let color = $('#color').val();

function enviar() {

    let nombre = $('#nombre').val();
    let apellido = $('#apellido').val();
    let profesion = $('#profesion').val();
    let numero = $('#numero').val();
    let color = $('#color').val();

    // Alerta
    let alertPlaceholder = document.getElementById('liveAlertPlaceholder')
    let appendAlert = (message, type) => {
        let wrapper = document.createElement('div')
        wrapper.innerHTML = [
            `<div class="alert alert-${type} alert-dismissible" role="alert">`,
            `   <div>${message}</div>`,
            '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
            '</div>'
        ].join('')

        alertPlaceholder.append(wrapper)
    }

    let alertTrigger = document.getElementById('liveAlertBtn')
    if (alertTrigger) {
        alertTrigger.addEventListener('click', () => {
            if (nombre === "" || apellido === "" ) {
                appendAlert('No se han completado los datos', 'danger');
                return;
            } else {
                appendAlert('Los datos han sido registrado con exito!', 'success')
            }
        })
    }

    // Toast
    let toastTrigger = document.getElementById('liveToastBtn')
    let toastLiveExample = document.getElementById('liveToast')

    if (toastTrigger) {
        let toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
        toastTrigger.addEventListener('click', () => {
            toastBootstrap.show()
        })
    }

    // Offcanvas
    $('#nombre-r').text(nombre); // .text() es como textContent()
    $('#apellido-r').text(apellido);
    $('#profesion-r').text(profesion);
    $('#numero-r').text(numero);
    $('#color-r').text(color);
}